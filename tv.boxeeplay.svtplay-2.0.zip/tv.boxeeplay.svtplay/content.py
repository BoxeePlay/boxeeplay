
baseurl = 'http://svtplay.se'

class videoitem:
    name = ''
    url = ''
    level = 'category'
    image = ''
    type= 'folder'
    desc=''

    
