import mc, svtplay, actions

'''
here we can do some pre launch processing if we wish.
checking authentication or pre-loading content, anything we need.
'''

mc.ActivateWindow(14000)
actions.home()
